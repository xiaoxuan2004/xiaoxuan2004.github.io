PIC coursework: install requirements, run download_reference.py, then analysis.py.
The source data are downloaded locally from the pinned public author repository. No input data or row predictions are included.
